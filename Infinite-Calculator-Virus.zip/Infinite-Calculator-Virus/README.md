# Infinite-Calculator-Virus
A VBScirpt based on a Notepad application that enables an infinite loop of Calculator application by tricking the user into giving permission via an unsuspecting pop up.
## !! FOR STOP IT !!
EXECUTE THIS COMMAND: taskkill /F /IM wscript.exe
## Download
this is supported only for windows OS. the code executes the o=moment you run it.


## DISCLAIMER
<b>
I AM IN NO WAY RESPONSIBLE FOR ANY ACTIONS CAUSED VIA THIS CODE. <b>
