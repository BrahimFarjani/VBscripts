# Virus-Prank-fake-virus-
A  vbs Script coded in Notepad with pre-written codes and outputs with sequential pop up system messages.

I AM NO WAY RESPONSIBLE FOR ANY ILLEGAL USE OF THIS CODE
# VBscripts
