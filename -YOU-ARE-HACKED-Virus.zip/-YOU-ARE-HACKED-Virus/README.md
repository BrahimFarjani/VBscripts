# Infinite-YOU-ARE-HACKED-Virus
a notepad based infinite loop script that multiplies itself continuously . \
<b>
I AM IN NO WAY RESPONSIBLE FOR ANY ACTIONS CAUSED VIA THIS CODE. <b>
